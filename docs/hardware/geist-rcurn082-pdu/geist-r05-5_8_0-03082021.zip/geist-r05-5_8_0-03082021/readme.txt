Files included in this package:

1. readme.txt  - this document
2. geist-r05-5_8_0.firmware - firmware to upload to device.
3. geist_v5.mib - Management information block.  For use with an SNMP console.
4. geist_v5_mibsheet.csv - SNMP info in CSV format if the SNMP console does not accept the MIB.
3. geist_legacy.mib - Management information block.  For use with an SNMP console.
4. geist_legacy_mibsheet.csv - SNMP info in CSV format if the SNMP console does not accept the MIB.

WARNING:
  Please read through the instructions thoroughly before proceeding to update your unit.
  Failure to follow the instructions exactly MAY damage your unit and MAY VOID YOUR WARRANTY.

Instructions for updating your device:

To update the firmware on your device.

	Open a web browser and browse to your device.
    Log in as administrator.
	Go to System/Utilities.
	Under 'Firmware Update' click 'Choose File' and select the geist-r05-5_8_0.firmware file.
	Click 'Submit' and wait for a restart of the device.
	
Should you run into any trouble while updating, please contact us.
  Phone : 1 888 630 4445
  E-mail: support@geistglobal.com
  Web   : www.geistglobal.com/support

Download new firmware releases at www.geistglobal.com

Version 5.8.0. Built on 03/08/2021
