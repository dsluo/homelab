Files included in this package:

1. readme.txt  - this document
2. geist-r04-5_2_1.firmware - firmware to upload to device.
3. geist_v5.mib - Management information block.  For use with an SNMP console.
4. geist_v5_mibsheet.csv - SNMP info in CSV format if the SNMP console does not accept the MIB.
3. geist_legacy.mib - Management information block.  For use with an SNMP console.
4. geist_legacy_mibsheet.csv - SNMP info in CSV format if the SNMP console does not accept the MIB.

WARNING:
  Please read through the instructions thoroughly before proceeding to update your unit.
  Failure to follow the instructions exactly MAY damage your unit and MAY VOID YOUR WARRANTY.

Instructions for updating your device:

To update the firmware on your device.

	Open a web browser and browse to your device.
    Log in as administrator.
	Go to System/Utilities.
	Under 'Firmware Update' click 'Choose File' and select the geist-r04-5_2_1.firmware file.
	Click 'Submit' and wait for a restart of the device.
	
Should you run into any trouble while updating, please contact us.
  Phone : 1-800-432-3219  |  +1 402 474 3400
  E-mail: support@geistglobal.com
  Web   : www.geistglobal.com/support

Download new firmware releases at www.geistglobal.com

Version 5.2.1. Built on 12/12/2017
